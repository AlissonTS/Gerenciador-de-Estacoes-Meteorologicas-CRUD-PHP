<?php

    header('location:../../paginaPrincipal.php');
