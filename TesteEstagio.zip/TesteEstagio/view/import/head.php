    
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href="css/bootstrap/bootstrap.css">
    <link rel="stylesheet" href="css/ambienteGerenciamento.css">
    <link rel="stylesheet" href="css/dropdownStyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.9.0/themes/base/jquery-ui.css">