        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#menu" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="paginaPrincipal.php" style="padding-top: 15px; padding-right: 10px; padding-bottom: 20px; padding-left: 10px;">
                ATS
            </a>
        </div>
