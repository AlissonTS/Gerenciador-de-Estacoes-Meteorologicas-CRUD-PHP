    
    <script src="js/jquery/jquery-3.2.1.js"></script>
    <script src="js/jquery/jquery.maskedinput.js"></script>
    <script src="js/bootstrap/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery/jquery.maskMoney.js"></script>
    <script type="text/javascript" src="js/dropdown.js"></script>