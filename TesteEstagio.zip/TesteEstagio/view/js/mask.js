        
        // $(document).ready(function(){
           // $("#data").mask("9999-99-99");
        // });
        
        $(document).ready(function(){
            $("#temperatura").maskMoney();
        });
        
        $(document).ready(function(){
            $("#velocidade_vento").maskMoney();
        });
        
        $(document).ready(function(){
            $("#umidade").maskMoney();
        });