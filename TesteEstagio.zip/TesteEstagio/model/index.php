<?php

    header('../location:view/paginaPrincipal.php');
